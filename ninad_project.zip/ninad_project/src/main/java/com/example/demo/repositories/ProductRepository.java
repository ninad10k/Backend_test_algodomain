package com.example.demo.repositories;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Product;

@Transactional
@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
//UPDATE `ninad`.`product` SET `pname` = 'dell 100', `ptype` = 'laptops', `pcategory` = 'electronicss', `price` = '100000' WHERE (`pid` = '1');
	@Modifying
	@Query(value="update product set pname = ?2 ,ptype = ?3,pcategory = ?4 ,price = ?5 where pid = ?1", nativeQuery = true)
	public void updateProduct(int pid,String pname,String ptype,String pcategory,double price);
}
