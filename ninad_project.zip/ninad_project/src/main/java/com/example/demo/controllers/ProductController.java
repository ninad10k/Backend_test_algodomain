package com.example.demo.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Product;
import com.example.demo.services.ProductService;

@RestController
public class ProductController {

	@Autowired
	ProductService pservice;
	
	@GetMapping("/allitems")
	public List<Product> GetAll()
	{
		return pservice.getAll();
	}

	@PostMapping("/findByid/{pid}")
    public Optional<Product> getProduct(@PathVariable("pid") int id) {
        return pservice.getProduct(id);
    }
	
	@PostMapping("/savecon")
	public Product savecontact(@RequestBody Product p)
	{
		return pservice.savec(p);
	}
	
	@DeleteMapping("/deleteById/{pid}")
	public ResponseEntity<String> deleteByID(@PathVariable("pid") int id)
	{	 
		Optional<Product> pm=pservice.getProduct(id);
		if(pm.isEmpty())
		{
			return new ResponseEntity<String>("Product doesnot exists",HttpStatus.NOT_FOUND);
		}
		pservice.delete(id);
		return new ResponseEntity<String>("Product is deleted",HttpStatus.OK);
	}
	
	@PostMapping("/updateproduct")
	public void updateProduct(@RequestBody Product p)
	{
		pservice.updateProduct(p.getPid(),p.getPname(),p.getPtype(),p.getPcategory(),p.getPrice());
	}
}
